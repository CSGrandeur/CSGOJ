﻿# Uninstall method(卸载方法)
#
# first execute this on terminal by root user
#(首先在root用户的桌面终端里执行如下语句):
sudo ./lodop uninstall

# or stop the lodop service on the app interface
#(或者在Lodop7程序界面上点停止服务)


# then delete this directory and its all files
#(然后删除如下目录及其所有文件):
# sudo rm -rf /usr/share/mounttaisoftware/lodop7

