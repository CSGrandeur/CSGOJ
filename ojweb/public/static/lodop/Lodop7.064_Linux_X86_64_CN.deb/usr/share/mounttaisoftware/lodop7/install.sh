﻿# Install method 1,execute this on terminal
#(安装方法1，在桌面终端中执行如下语句):
sudo ./lodop install


# Install method 2(安装方法2):
# double click "lodop" in this directory on linux desktop of root user
#(在root用户桌面，双击安装目录下的lodop主文件)
