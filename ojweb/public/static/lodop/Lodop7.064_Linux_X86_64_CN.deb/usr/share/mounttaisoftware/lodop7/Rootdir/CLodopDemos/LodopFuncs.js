﻿//本JS是加载CLodop/Lodop7服务的综合示例，可直接使用，建议看懂后融进自己页面程序

//用双端口加载主JS文件Lodop.js(或CLodopfuncs.js兼容老版本)以防其中某端口被占:
var MainJS ="CLodopfuncs.js",
    URL_WS1   = "ws://localhost:8000/"+MainJS,                //ws用8000/18000
    URL_WS2   = "ws://localhost:18000/"+MainJS,
    URL_HTTP1 = "http://localhost:8000/"+MainJS,              //http用8000/18000
    URL_HTTP2 = "http://localhost:18000/"+MainJS,
    URL_HTTP3 = "https://localhost.lodop.net:8443/"+MainJS;   //https用8000/8443


var LoadJsState,LodopIsWinLocal;

//==检查加载成功与否，如没成功则用http(s)再试==
//==低版本CLODOP6.561/Lodop7.043及前)用本方法==
function checkOrTryHttp() {
  if (window.getCLodop) {
     LoadJsState = "complete";
     return true;
  }
  if (LoadJsState == "loadingB" || LoadJsState == "complete") return;
  LoadJsState = "loadingB";
  var head = document.head || document.getElementsByTagName("head")[0] || document.documentElement;
  var JS1 = document.createElement("script")
     ,JS2 = document.createElement("script")
     ,JS3 = document.createElement("script");
  JS1.src = URL_HTTP1;
  JS2.src = URL_HTTP2;
  JS3.src = URL_HTTP3;
  JS1.onload = JS2.onload = JS3.onload = JS2.onerror = JS3.onerror=function(){LoadJsState = "complete";}
  JS1.onerror = function(e) {
      if (window.location.protocol !== 'https:')
          head.insertBefore(JS2, head.firstChild); else
          head.insertBefore(JS3, head.firstChild);
  }
  head.insertBefore(JS1,head.firstChild);
}

//==加载Lodop对象的主过程:==
(function loadCLodop(){
  LodopIsWinLocal = !!((URL_WS1 + URL_WS2).match(/\/\/localho|\/\/127.0.0./i));
  LodopIsWinLocal= LodopIsWinLocal && (navigator.platform.indexOf("Win")==0);

  LoadJsState = "loadingA";
  if (!window.WebSocket && window.MozWebSocket) window.WebSocket=window.MozWebSocket;
  //ws方式速度快(小于200ms)且可避免CORS错误,但要求Lodop版本足够新:
  try {
      var WSK1=new WebSocket(URL_WS1);
      WSK1.onopen = function(e) { setTimeout("checkOrTryHttp();",200); }
      WSK1.onmessage = function(e) {if (!window.getCLodop) eval(e.data);}
      WSK1.onerror = function(e) {
           var WSK2=new WebSocket(URL_WS2);
           WSK2.onopen = function(e) {setTimeout("checkOrTryHttp();",200);}
           WSK2.onmessage = function(e) {if (!window.getCLodop) eval(e.data);}
           WSK2.onerror= function(e) {checkOrTryHttp();}
      }
  } catch(e){
    checkOrTryHttp();
  }
})();

//==获取LODOP对象的主过程，判断是否安装、需否升级:==
function getLodop() {
    var strLodopInstall_1 = "<br><font color='#FF00FF'>Web打印服务Lodop未安装启动，点击这里<a href='Lodop_setup.zip' target='_self'>下载执行安装</a>";
    var strLodopInstall_2 = "<br>（若此前已安装过，可<a href='CLodop.protocol:setup' target='_self'>点这里直接再次启动</a>）";
    var strLodopInstall_3 = "，成功后请刷新本页面。</font>";
    var strLodopUpdate = "<br><font color='#FF00FF'>Web打印服务Lodop需升级!点击这里<a href='Lodop_setup.zip' target='_self'>执行升级</a>,升级后请刷新页面。</font>";
    var LODOP;
    try {
        try {
            LODOP = window.getCLodop();
        } catch (err) {}
        if (!LODOP && LoadJsState !== "complete") {
            if (!LoadJsState) 
               alert("没有加载Lodop的主JS，请先执行loadCLodop()过程"); else 
               alert("网页还没下载完毕，请稍等一下再操作.");
            return;
        }
        if (!LODOP) {
            document.body.innerHTML = strLodopInstall_1 + (LodopIsWinLocal ? strLodopInstall_2 : "") + strLodopInstall_3 + document.body.innerHTML;
            return;
        } else {
            if (LODOP.VERSION < "7.0.4.9") {
                document.body.innerHTML = strLodopUpdate + document.body.innerHTML;
            }
        }
        //======获取成功后，如下空白位置适合调用统一功能(如注册语句等):======


        //===================================================================
        return LODOP;
    } catch (err) {
        alert("getLodop出错:" + err);
    }
}
